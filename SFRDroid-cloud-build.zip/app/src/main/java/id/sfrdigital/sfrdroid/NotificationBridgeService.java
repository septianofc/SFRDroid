package id.sfrdigital.sfrdroid;

import android.app.Notification;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import androidx.work.*;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.*;

public class NotificationBridgeService extends NotificationListenerService {
 @Override public void onNotificationPosted(StatusBarNotification sbn){
  if(sbn==null||sbn.getPackageName()==null||!Config.standby(this))return;
  if(!Config.apps(this).contains(sbn.getPackageName()))return;
  try{
   Notification n=sbn.getNotification();Bundle ex=n.extras;Set<String> chosen=Config.fields(this);JSONObject event=new JSONObject();
   event.put("event","notification_posted");event.put("event_id",UUID.randomUUID().toString());
   put(event,chosen,"package_name",sbn.getPackageName());
   put(event,chosen,"app_name",appName(sbn.getPackageName()));
   put(event,chosen,"title",safe(ex==null?null:ex.getCharSequence(Notification.EXTRA_TITLE)));
   CharSequence text=ex==null?null:ex.getCharSequence(Notification.EXTRA_BIG_TEXT);
   if(text==null&&ex!=null)text=ex.getCharSequence(Notification.EXTRA_TEXT);
   put(event,chosen,"text",safe(text));
   put(event,chosen,"posted_at",new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX",Locale.US).format(new Date(sbn.getPostTime())));
   put(event,chosen,"notification_id",sbn.getId());
   put(event,chosen,"notification_tag",sbn.getTag()==null?JSONObject.NULL:sbn.getTag());
   put(event,chosen,"is_ongoing",(n.flags&Notification.FLAG_ONGOING_EVENT)!=0);
   put(event,chosen,"is_clearable",sbn.isClearable());
   Data data=new Data.Builder().putString("payload",event.toString()).build();
   Constraints cons=new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build();
   OneTimeWorkRequest req=new OneTimeWorkRequest.Builder(UploadWorker.class).setInputData(data).setConstraints(cons).build();
   WorkManager.getInstance(getApplicationContext()).enqueue(req);
  }catch(Exception ignored){}
 }
 private void put(JSONObject o,Set<String>s,String k,Object v)throws Exception{if(s.contains(k))o.put(k,v);}
 private String safe(CharSequence c){return c==null?"":c.toString();}
 private String appName(String p){try{return String.valueOf(getPackageManager().getApplicationLabel(getPackageManager().getApplicationInfo(p,0)));}catch(Exception e){return p;}}
}
