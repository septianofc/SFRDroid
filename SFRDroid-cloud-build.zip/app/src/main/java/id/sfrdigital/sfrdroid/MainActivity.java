package id.sfrdigital.sfrdroid;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.provider.Settings;
import android.view.ViewGroup;
import android.widget.*;
import androidx.work.*;
import java.util.*;
import java.util.concurrent.TimeUnit;

public class MainActivity extends Activity {
 private EditText url,token;
 private RadioGroup method;
 private LinearLayout appList, fieldList;
 private TextView status;
 private final Map<String,CheckBox> appChecks=new LinkedHashMap<>();
 private final Map<String,CheckBox> fieldChecks=new LinkedHashMap<>();
 private static final String[][] FIELDS={{"app_name","Nama aplikasi"},{"package_name","Package name"},{"title","Judul notifikasi"},{"text","Isi pesan"},{"posted_at","Waktu notifikasi"},{"notification_id","ID notifikasi"},{"notification_tag","Tag notifikasi"},{"is_ongoing","Notifikasi ongoing"},{"is_clearable","Bisa dihapus"}};

 @Override public void onCreate(Bundle b){super.onCreate(b);
  ScrollView scroll=new ScrollView(this); LinearLayout root=new LinearLayout(this); root.setOrientation(1); root.setPadding(24,24,24,32); root.setBackgroundColor(Color.rgb(18,18,18)); scroll.addView(root);
  TextView h=txt("SFR Droid",26,true); root.addView(h);
  TextView sub=txt("Notification Bridge • #42A5F5",14,false); sub.setTextColor(Color.rgb(66,165,245)); root.addView(sub);
  root.addView(section("1. Koneksi API"));
  url=new EditText(this); url.setSingleLine(true); url.setHint("https://domain.id/api.php atau webhook"); url.setText(Config.url(this)); styleInput(url); root.addView(url,lp());
  token=new EditText(this); token.setSingleLine(true); token.setHint("Token Bearer (kosongkan jika webhook tanpa token)"); token.setText(Config.token(this)); styleInput(token); root.addView(token,lp());
  TextView mt=txt("Metode pengiriman",15,true); root.addView(mt);
  method=new RadioGroup(this); method.setOrientation(0);
  RadioButton php=new RadioButton(this); php.setText("PHP/API"); php.setTextColor(Color.WHITE); php.setId(1);
  RadioButton hook=new RadioButton(this); hook.setText("Webhook"); hook.setTextColor(Color.WHITE); hook.setId(2);
  method.addView(php);method.addView(hook);method.check("webhook".equals(Config.mode(this))?2:1);root.addView(method);

  root.addView(section("2. Pilih aplikasi"));
  TextView hint=txt("Centang minimal satu aplikasi. Pilih Semua untuk memantau semua aplikasi yang terdeteksi.",13,false);root.addView(hint);
  Button all=new Button(this);all.setText("Pilih Semua");all.setOnClickListener(v->{for(CheckBox c:appChecks.values())c.setChecked(true);});root.addView(all,lp());
  Button none=new Button(this);none.setText("Kosongkan Pilihan");none.setOnClickListener(v->{for(CheckBox c:appChecks.values())c.setChecked(false);});root.addView(none,lp());
  appList=new LinearLayout(this);appList.setOrientation(1);root.addView(appList,lp());loadApps();

  root.addView(section("3. Pilih data yang dikirim"));
  fieldList=new LinearLayout(this);fieldList.setOrientation(1);root.addView(fieldList,lp());
  Set<String> selectedFields=Config.fields(this);
  for(String[] f:FIELDS){CheckBox c=new CheckBox(this);c.setText(f[1]);c.setTextColor(Color.WHITE);c.setButtonTintList(android.content.res.ColorStateList.valueOf(0xFF42A5F5));c.setChecked(selectedFields.contains(f[0]));fieldChecks.put(f[0],c);fieldList.addView(c);}

  root.addView(section("4. Status layanan"));
  status=txt("",14,false);root.addView(status);
  Button access=button("Buka izin pembaca notifikasi");access.setOnClickListener(v->startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)));root.addView(access,lp());
  Button battery=button("Buka pengaturan baterai aplikasi");battery.setOnClickListener(v->{Intent i=new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);i.setData(android.net.Uri.parse("package:"+getPackageName()));startActivity(i);});root.addView(battery,lp());
  Button save=button("Simpan semua pengaturan");save.setOnClickListener(v->saveConfig(false));root.addView(save,lp());
  Button standby=button(Config.standby(this)?"Matikan Standby (OFF)":"Nyalakan Standby");standby.setOnClickListener(v->{saveConfig(true);});root.addView(standby,lp());
  Button hb=button("Kirim heartbeat sekarang");hb.setOnClickListener(v->{HeartbeatWorker.enqueueNow(this);Toast.makeText(this,"Heartbeat dijadwalkan.",Toast.LENGTH_SHORT).show();});root.addView(hb,lp());
  setContentView(scroll);updateStatus();
 }
 private void loadApps(){
  appList.removeAllViews();appChecks.clear();PackageManager pm=getPackageManager();
  List<ApplicationInfo> list=pm.getInstalledApplications(PackageManager.GET_META_DATA);
  Collections.sort(list,(a,b)->String.valueOf(pm.getApplicationLabel(a)).compareToIgnoreCase(String.valueOf(pm.getApplicationLabel(b))));
  Set<String> saved=Config.apps(this);
  for(ApplicationInfo ai:list){
   String pkg=ai.packageName;
   if(pkg.equals(getPackageName())) continue;
   CheckBox c=new CheckBox(this);c.setText(String.valueOf(pm.getApplicationLabel(ai))+"  ("+pkg+")");c.setTextColor(Color.WHITE);c.setButtonTintList(android.content.res.ColorStateList.valueOf(0xFF42A5F5));c.setChecked(saved.contains(pkg));
   appChecks.put(pkg,c);appList.addView(c);
  }
 }
 private void saveConfig(boolean toggle){
  Set<String> apps=new HashSet<>(),fields=new HashSet<>();
  for(Map.Entry<String,CheckBox> e:appChecks.entrySet())if(e.getValue().isChecked())apps.add(e.getKey());
  for(Map.Entry<String,CheckBox> e:fieldChecks.entrySet())if(e.getValue().isChecked())fields.add(e.getKey());
  if(apps.isEmpty()){Toast.makeText(this,"Pilih minimal satu aplikasi.",Toast.LENGTH_LONG).show();return;}
  if(fields.isEmpty()){Toast.makeText(this,"Pilih minimal satu jenis data.",Toast.LENGTH_LONG).show();return;}
  String endpoint=url.getText().toString().trim(), secret=token.getText().toString().trim();
  if(!endpoint.startsWith("https://")){Toast.makeText(this,"Gunakan URL HTTPS.",Toast.LENGTH_LONG).show();return;}
  boolean isHook=method.getCheckedRadioButtonId()==2;
  if(!isHook&&secret.length()<24){Toast.makeText(this,"Token PHP/API minimal 24 karakter.",Toast.LENGTH_LONG).show();return;}
  boolean active=toggle?!Config.standby(this):Config.standby(this);
  Config.save(this,endpoint,secret,isHook?"webhook":"php",active,apps,fields);
  if(active)scheduleHeartbeat();else WorkManager.getInstance(this).cancelUniqueWork("sfrdroid-heartbeat");
  Toast.makeText(this,active?"Pengaturan tersimpan • Standby ON":"Pengaturan tersimpan • Standby OFF",Toast.LENGTH_LONG).show();updateStatus();recreate();
 }
 private void scheduleHeartbeat(){
  Constraints c=new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build();
  PeriodicWorkRequest r=new PeriodicWorkRequest.Builder(HeartbeatWorker.class,15,TimeUnit.MINUTES).setConstraints(c).build();
  WorkManager.getInstance(this).enqueueUniquePeriodicWork("sfrdroid-heartbeat",ExistingPeriodicWorkPolicy.UPDATE,r);
 }
 private void updateStatus(){if(status!=null)status.setText("Standby: "+(Config.standby(this)?"ON":"OFF")+"\nAplikasi dipilih: "+Config.apps(this).size()+"\nAPI: "+(Config.url(this).isEmpty()?"belum diatur":"tersimpan")+"\nAkses notifikasi: periksa di pengaturan Android.");}
 private TextView section(String s){TextView t=txt(s,18,true);t.setPadding(0,22,0,8);return t;}
 private TextView txt(String s,int size,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(Color.WHITE);if(bold)t.setTypeface(null,Typeface.BOLD);return t;}
 private Button button(String s){Button b=new Button(this);b.setText(s);b.setTextColor(Color.WHITE);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF42A5F5));return b;}
 private void styleInput(EditText e){e.setTextColor(Color.WHITE);e.setHintTextColor(0xFFAAAAAA);e.setSingleLine(true);}
 private LinearLayout.LayoutParams lp(){return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);}
}
