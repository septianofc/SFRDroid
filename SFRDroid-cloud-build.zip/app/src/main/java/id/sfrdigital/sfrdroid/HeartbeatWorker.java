package id.sfrdigital.sfrdroid;
import android.content.Context;
import androidx.annotation.NonNull;
import androidx.work.*;
public class HeartbeatWorker extends Worker {
 public HeartbeatWorker(@NonNull Context c,@NonNull WorkerParameters p){super(c,p);}
 @NonNull @Override public Result doWork(){
  if(!Config.standby(getApplicationContext())) return Result.success();
  return HeartbeatPostWorker.send(getApplicationContext());
 }
 public static void enqueueNow(Context c){
  Constraints k=new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build();
  WorkManager.getInstance(c).enqueue(new OneTimeWorkRequest.Builder(HeartbeatPostWorker.class).setConstraints(k).build());
 }
}
