package id.sfrdigital.sfrdroid;
import android.content.Context;
import android.provider.Settings;
public final class DeviceId {private DeviceId(){} public static String get(Context c){String s=Settings.Secure.getString(c.getContentResolver(),Settings.Secure.ANDROID_ID);return s==null?"unknown":s;}}
