package id.sfrdigital.sfrdroid;
import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.HashSet;
import java.util.Set;

public final class Config {
 private static final String P="sfrdroid_cfg";
 private Config(){}
 private static SharedPreferences p(Context c){return c.getSharedPreferences(P,Context.MODE_PRIVATE);}
 public static String url(Context c){return p(c).getString("url","");}
 public static String token(Context c){return p(c).getString("token","");}
 public static String mode(Context c){return p(c).getString("mode","php");}
 public static boolean standby(Context c){return p(c).getBoolean("standby",false);}
 public static Set<String> apps(Context c){return new HashSet<>(p(c).getStringSet("apps",new HashSet<>()));}
 public static Set<String> fields(Context c){return new HashSet<>(p(c).getStringSet("fields",new HashSet<String>(){{add("app_name");add("package_name");add("title");add("text");add("posted_at");}}));}
 public static void save(Context c,String url,String token,String mode,boolean standby,Set<String> apps,Set<String> fields){
  p(c).edit().putString("url",url.trim()).putString("token",token.trim()).putString("mode",mode)
   .putBoolean("standby",standby).putStringSet("apps",new HashSet<>(apps)).putStringSet("fields",new HashSet<>(fields)).apply();
 }
}
