package id.sfrdigital.sfrdroid;
import android.content.Context;
import androidx.annotation.NonNull;
import androidx.work.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import org.json.JSONObject;

public class UploadWorker extends Worker {
 public UploadWorker(@NonNull Context c,@NonNull WorkerParameters p){super(c,p);}
 @NonNull @Override public Result doWork(){
  String endpoint=Config.url(getApplicationContext()),token=Config.token(getApplicationContext()),payload=getInputData().getString("payload");
  if(endpoint.isEmpty())return Result.failure();
  if(payload==null){try{JSONObject h=new JSONObject();h.put("event","heartbeat");h.put("device_id",DeviceId.get(getApplicationContext()));h.put("app_version","1.0.0");h.put("sent_at",System.currentTimeMillis());payload=h.toString();}catch(Exception e){return Result.failure();}}
  HttpURLConnection c=null;
  try{
   c=(HttpURLConnection)new URL(endpoint).openConnection();c.setRequestMethod("POST");c.setConnectTimeout(15000);c.setReadTimeout(15000);c.setDoOutput(true);
   c.setRequestProperty("Content-Type","application/json; charset=utf-8");c.setRequestProperty("Accept","application/json");
   if(!token.isEmpty())c.setRequestProperty("Authorization","Bearer "+token);
   byte[] b=payload.getBytes(StandardCharsets.UTF_8);c.setFixedLengthStreamingMode(b.length);try(OutputStream o=c.getOutputStream()){o.write(b);}
   int code=c.getResponseCode();InputStream in=(code>=200&&code<400)?c.getInputStream():c.getErrorStream();
   if(in!=null)try(BufferedReader r=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8))){while(r.readLine()!=null){}}
   if(code>=200&&code<300)return Result.success();if(code==408||code==429||code>=500)return Result.retry();return Result.failure();
  }catch(Exception e){return Result.retry();}finally{if(c!=null)c.disconnect();}
 }
}
