package id.sfrdigital.sfrdroid;
import android.content.Context;
import androidx.annotation.NonNull;
import androidx.work.*;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import org.json.JSONObject;
public class HeartbeatPostWorker extends Worker {
 public HeartbeatPostWorker(@NonNull Context c,@NonNull WorkerParameters p){super(c,p);}
 @NonNull @Override public Result doWork(){return send(getApplicationContext());}
 public static Result send(Context context){
  String endpoint=Config.url(context),token=Config.token(context);if(endpoint.isEmpty())return Result.failure();
  HttpURLConnection c=null;try{
   JSONObject h=new JSONObject();h.put("event","heartbeat");h.put("device_id",DeviceId.get(context));h.put("app_version","1.0.0");h.put("sent_at",System.currentTimeMillis());
   c=(HttpURLConnection)new URL(endpoint).openConnection();c.setRequestMethod("POST");c.setConnectTimeout(15000);c.setReadTimeout(15000);c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json; charset=utf-8");if(!token.isEmpty())c.setRequestProperty("Authorization","Bearer "+token);
   byte[] b=h.toString().getBytes(StandardCharsets.UTF_8);c.setFixedLengthStreamingMode(b.length);try(OutputStream o=c.getOutputStream()){o.write(b);}int code=c.getResponseCode();if(code>=200&&code<300)return Result.success();if(code==408||code==429||code>=500)return Result.retry();return Result.failure();
  }catch(Exception e){return Result.retry();}finally{if(c!=null)c.disconnect();}
 }
}
