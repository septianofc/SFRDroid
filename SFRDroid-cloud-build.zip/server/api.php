<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
$expected = getenv('BRIDGE_TOKEN') ?: 'CHANGE_THIS_TO_A_LONG_RANDOM_SECRET_TOKEN';
$auth = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
if ($expected === 'CHANGE_THIS_TO_A_LONG_RANDOM_SECRET_TOKEN' ||
    !preg_match('/^Bearer\s+(.+)$/i', $auth, $m) || !hash_equals($expected, trim($m[1]))) {
 http_response_code(401); echo json_encode(['ok'=>false,'error'=>'unauthorized']); exit;
}
if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') { header('Allow: POST'); http_response_code(405); echo json_encode(['ok'=>false,'error'=>'method_not_allowed']); exit; }
if (stripos($_SERVER['CONTENT_TYPE'] ?? '', 'application/json') === false) { http_response_code(415); echo json_encode(['ok'=>false,'error'=>'json_required']); exit; }
$raw=file_get_contents('php://input');
if ($raw===false || strlen($raw)>65536) { http_response_code(413); echo json_encode(['ok'=>false,'error'=>'payload_too_large']); exit; }
$data=json_decode($raw,true);
if (!is_array($data) || !in_array($data['event'] ?? '', ['notification_posted','heartbeat'], true)) { http_response_code(400); echo json_encode(['ok'=>false,'error'=>'invalid_payload']); exit; }
$dir=getenv('BRIDGE_DATA_DIR') ?: dirname(__DIR__).'/private_bridge_data';
if (!is_dir($dir) && !mkdir($dir,0700,true) && !is_dir($dir)) { http_response_code(500); echo json_encode(['ok'=>false,'error'=>'storage_unavailable']); exit; }
$line=json_encode(['received_at'=>gmdate('c'),'data'=>$data],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
if ($line===false || file_put_contents($dir.'/events-'.gmdate('Y-m').'.jsonl',$line.PHP_EOL,FILE_APPEND|LOCK_EX)===false) { http_response_code(500); echo json_encode(['ok'=>false,'error'=>'write_failed']); exit; }
echo json_encode(['ok'=>true,'event'=>$data['event']]);
