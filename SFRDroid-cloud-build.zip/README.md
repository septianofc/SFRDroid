# SFR Droid — Android notification bridge
Starter source project (Java / Android Studio) plus PHP receiver.

## Important
This is source code, not a precompiled APK. It has not been built or device-tested in this environment. Android does not permit an app to silently grant its own notification-access permission or universally bypass battery restrictions. The user must enable Notification Access in system settings. The app asks the user to open relevant settings; it cannot guarantee unrestricted operation.

## Configure server
1. Upload `server/api.php` to an HTTPS PHP host.
2. Configure environment variable `BRIDGE_TOKEN` to a long random secret. The PHP API intentionally rejects requests if the placeholder token is unchanged.
3. Optionally set `BRIDGE_DATA_DIR` to a private writable directory outside the public web root.
4. Enter the same HTTPS endpoint and token in the app. PHP/API requires a token; webhook mode permits a blank token if the receiving endpoint is configured that way. Both send JSON POST.

## Build
1. Install Android Studio and Android SDK Platform 35.
2. Open this directory and sync Gradle.
3. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Install `app/build/outputs/apk/debug/app-debug.apk` on a test device.
5. Open SFR Droid, enter URL, choose PHP/API or Webhook, select apps and fields, save, then enable Notification Access in Android Settings.
6. Turn Standby ON to enable event forwarding and heartbeat scheduling; OFF disables forwarding and cancels periodic heartbeat.

## Limitations
- Package list uses QUERY_ALL_PACKAGES, suitable for sideload/testing but Google Play restricts broad package visibility to approved use cases.
- Notification text availability depends on each app and Android privacy rules. It cannot read content that is not exposed to notification listeners.
- WorkManager periodic work is inexact and may be delayed by Android; 15 minutes is its minimum periodic interval. Force-stop, OEM battery controls, reboot behavior, or revoked access may interrupt service.
- Event jobs use WorkManager retry for transient network/server errors, but this starter does not persist a durable local Room queue. Production should add Room, token encryption, deduplication, rate limits, log retention, and app selection changes.
- Notification content can include sensitive messages or OTPs. Use only on devices you own or are authorized to monitor, and send to an endpoint you control.
